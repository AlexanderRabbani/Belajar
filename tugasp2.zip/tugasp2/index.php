<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas Pertemuan 2</title>
</head>
<body>
    <h3>Soal Tugas Pertemuan 2</h3>
    <h4>1. Buatlah sistem untuk penilaian atau grading hasil ujian: </h4>
        <p>Ada input / variable untuk menampung nilai</p>
        <p>misal, nilai 78.</p>

        <li>Jika nilai 80 sampai 100 maka grade adalah A dan LULUS</li>
        <li>Jika nilai 70 sampai 80 maka grade adalah B+ dan LULUS</li>
        <li>Jika nilai 65 sampai 70 maka grade adalah B dan LULUS</li>
        <li>Jika nilai 60 sampai 65 maka grade adalah C+ dan LULUS</li>
        <li>Jika nilai 55 sampai 60 maka grade adalah C dan TIDAK LULUS</li>
        <li>Jika nilai 45 sampai 55 maka grade adalah D dan TIDAK LULUS</li>
        <li>Jika nilai di bawah 45 maka nilai adalah E dan TIDAK LULUS</li>


    <h4>2. Buatlah perulangan dengan for dari 1 sampai 10 </h4>
    <h4>3. Buatlah perulangan dengan while dari 10 - 20 </h4>
    <h4>4. Buatlah perulangan dengan while do 15 - 25 </h4>
    <h4>5. Buatlah perulangan dari 1 sampai 100 hanya bilangan genap </h4>
    <h4>6. Buatlah perulangan dari 1 sampai 100 hanya nilai ganjil </h4>
    <h4>7. Buatlah perulangan tangga seperti output di bawah ini </h4>
    <P>#####</P>
    <P>####</P>
    <P>###</P>
    <P>##</P>
    <P>#</P>

    <h4>8. Buat sistem stok untuk barang di setiap store. </h4>
    <P> Jadi ada 3 store</P>
    <P> Di central kitchen ada bahan utama, misal 7kg tepung </P>
    <P>nah, masing masing store harus ada minimal 2 kilo tepung.</P>
    <P>Jika total tepung nya kurang, maka akan ditampilkan echo “tepung kurang”, jika lebih atau sama maka akan ditampilkan echo “Stok tepung cukup”</P>

    <a href="./jawaban.php">JAWABAN</a>
</body>
</html>